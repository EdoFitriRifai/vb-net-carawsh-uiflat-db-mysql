﻿Public Class PilihanMenu
    Private Sub PilihanMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = FormBorderStyle.None
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Produk.PanelMenupilihan.Controls.Clear()
        CuciMobil.TopLevel = False
        CuciMobil.AutoSize = False
        CuciMobil.FormBorderStyle = FormBorderStyle.None
        CuciMobil.Dock = DockStyle.Fill
        Produk.PanelMenupilihan.Controls.Add(CuciMobil)
        CuciMobil.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Produk.PanelMenupilihan.Controls.Clear()
        MakanandanMinuman.TopLevel = False
        MakanandanMinuman.AutoSize = False
        MakanandanMinuman.FormBorderStyle = FormBorderStyle.None
        MakanandanMinuman.Dock = DockStyle.Fill
        Produk.PanelMenupilihan.Controls.Add(MakanandanMinuman)
        MakanandanMinuman.Show()
    End Sub
End Class