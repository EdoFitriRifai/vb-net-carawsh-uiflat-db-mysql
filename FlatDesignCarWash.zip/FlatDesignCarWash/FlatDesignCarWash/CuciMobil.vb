﻿Public Class CuciMobil
    Dim tottambah, subtotal As Double
    Dim tambah() As CheckBox
    Dim hargatambah() As Integer = {10000, 15000, 20000}
    Dim cuci1, cuci2, cuci3 As String


    Private Sub CuciMobil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = FormBorderStyle.None
        bersihpilih()
        tambah = New CheckBox() {tambah1, tambah2, tambah3}
    End Sub
    Sub bersihpilih()
        txtnama.Text = ""
        txtharga.Text = ""
        cmbjumlah.Text = ""
        tambah1.Checked = False
        tambah2.Checked = False
        tambah3.Checked = False
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Me.Close()

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Produk.PanelMenupilihan.Controls.Clear()
        PilihanMenu.TopLevel = False
        PilihanMenu.AutoSize = False
        PilihanMenu.FormBorderStyle = FormBorderStyle.None
        PilihanMenu.Dock = DockStyle.Fill
        Produk.PanelMenupilihan.Controls.Add(PilihanMenu)
        PilihanMenu.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        txtnama.Text = "Mini Bus"
        txtharga.Text = "15000"
        cmbjumlah.Focus()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        txtnama.Text = "Bus"
        txtharga.Text = "25000"
        cmbjumlah.Focus()
    End Sub

    Private Sub PictureBox6_Click_1(sender As Object, e As EventArgs) Handles PictureBox6.Click
        txtnama.Text = "Truk"
        txtharga.Text = "30000"
        cmbjumlah.Focus()
    End Sub

    Private Sub PictureBox5_Click_1(sender As Object, e As EventArgs) Handles PictureBox5.Click
        txtnama.Text = "Super Bus"
        txtharga.Text = "50000"
        cmbjumlah.Focus()
    End Sub



    Private Sub btnenter_Click_1(sender As Object, e As EventArgs) Handles btnenter.Click
        Dim i As Integer
        subtotal = 0
        tottambah = 0
        For i = 0 To 2
            If tambah(i).Checked Then
                tottambah = tottambah + hargatambah(i)
            End If
        Next
        Produk.lbljmlh.Text = Val(txtharga.Text) * Val(cmbjumlah.Text) + Val(tottambah)
        subtotal = Produk.lbljmlh.Text
        Dim item As New ListViewItem(txtnama.Text)
        item.SubItems.Add(cmbjumlah.Text)
        item.SubItems.Add(cuci1)
        item.SubItems.Add(cuci2)
        item.SubItems.Add(cuci3)
        item.SubItems.Add(subtotal)
        Produk.ListView1.Items.Add(item)
        bersihpilih()
    End Sub

    Private Sub tambah3_CheckedChanged(sender As Object, e As EventArgs) Handles tambah3.CheckedChanged
        If tambah3.Checked = True Then
            cuci3 = "ya"
        Else
            cuci3 = ""
        End If
    End Sub

    Private Sub tambah1_CheckedChanged(sender As Object, e As EventArgs) Handles tambah1.CheckedChanged
        If tambah1.Checked = True Then
            cuci1 = "ya"
        Else
            cuci1 = ""
        End If
    End Sub
    Private Sub tambah2_CheckedChanged(sender As Object, e As EventArgs) Handles tambah2.CheckedChanged
        If tambah2.Checked = True Then
            cuci2 = "ya"
        Else
            cuci2 = ""
        End If
    End Sub
End Class