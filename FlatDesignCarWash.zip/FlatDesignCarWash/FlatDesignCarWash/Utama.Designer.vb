﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Utama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Utama))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.btnpengaturan = New System.Windows.Forms.Button()
        Me.btnlaporan = New System.Windows.Forms.Button()
        Me.btnproduk = New System.Windows.Forms.Button()
        Me.btndashboard = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.jabatan = New System.Windows.Forms.Label()
        Me.namaAnggota = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PanelUtama = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.btnmax = New System.Windows.Forms.Button()
        Me.btnminimize = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Panel1.Controls.Add(Me.btnlogout)
        Me.Panel1.Controls.Add(Me.btnpengaturan)
        Me.Panel1.Controls.Add(Me.btnlaporan)
        Me.Panel1.Controls.Add(Me.btnproduk)
        Me.Panel1.Controls.Add(Me.btndashboard)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(189, 536)
        Me.Panel1.TabIndex = 1
        '
        'btnlogout
        '
        Me.btnlogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnlogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnlogout.FlatAppearance.BorderSize = 0
        Me.btnlogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlogout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnlogout.Image = CType(resources.GetObject("btnlogout.Image"), System.Drawing.Image)
        Me.btnlogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnlogout.Location = New System.Drawing.Point(0, 491)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.btnlogout.Size = New System.Drawing.Size(189, 45)
        Me.btnlogout.TabIndex = 9
        Me.btnlogout.Text = "  Logout"
        Me.btnlogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnlogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnlogout.UseVisualStyleBackColor = True
        '
        'btnpengaturan
        '
        Me.btnpengaturan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnpengaturan.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnpengaturan.FlatAppearance.BorderSize = 0
        Me.btnpengaturan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.btnpengaturan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpengaturan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpengaturan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnpengaturan.Image = CType(resources.GetObject("btnpengaturan.Image"), System.Drawing.Image)
        Me.btnpengaturan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnpengaturan.Location = New System.Drawing.Point(0, 343)
        Me.btnpengaturan.Name = "btnpengaturan"
        Me.btnpengaturan.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.btnpengaturan.Size = New System.Drawing.Size(189, 50)
        Me.btnpengaturan.TabIndex = 7
        Me.btnpengaturan.Text = "   Pengaturan"
        Me.btnpengaturan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnpengaturan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnpengaturan.UseVisualStyleBackColor = True
        '
        'btnlaporan
        '
        Me.btnlaporan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnlaporan.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnlaporan.FlatAppearance.BorderSize = 0
        Me.btnlaporan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.btnlaporan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlaporan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlaporan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnlaporan.Image = CType(resources.GetObject("btnlaporan.Image"), System.Drawing.Image)
        Me.btnlaporan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnlaporan.Location = New System.Drawing.Point(0, 293)
        Me.btnlaporan.Name = "btnlaporan"
        Me.btnlaporan.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.btnlaporan.Size = New System.Drawing.Size(189, 50)
        Me.btnlaporan.TabIndex = 6
        Me.btnlaporan.Text = "   Laporan"
        Me.btnlaporan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnlaporan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnlaporan.UseVisualStyleBackColor = True
        '
        'btnproduk
        '
        Me.btnproduk.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnproduk.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnproduk.FlatAppearance.BorderSize = 0
        Me.btnproduk.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.btnproduk.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnproduk.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnproduk.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnproduk.Image = CType(resources.GetObject("btnproduk.Image"), System.Drawing.Image)
        Me.btnproduk.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnproduk.Location = New System.Drawing.Point(0, 243)
        Me.btnproduk.Name = "btnproduk"
        Me.btnproduk.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.btnproduk.Size = New System.Drawing.Size(189, 50)
        Me.btnproduk.TabIndex = 3
        Me.btnproduk.Text = "   Product"
        Me.btnproduk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnproduk.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnproduk.UseVisualStyleBackColor = True
        '
        'btndashboard
        '
        Me.btndashboard.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btndashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.btndashboard.FlatAppearance.BorderSize = 0
        Me.btndashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.btndashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndashboard.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndashboard.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btndashboard.Image = CType(resources.GetObject("btndashboard.Image"), System.Drawing.Image)
        Me.btndashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btndashboard.Location = New System.Drawing.Point(0, 193)
        Me.btndashboard.Name = "btndashboard"
        Me.btndashboard.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.btndashboard.Size = New System.Drawing.Size(189, 50)
        Me.btndashboard.TabIndex = 2
        Me.btndashboard.Text = "   Dashboard"
        Me.btndashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btndashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btndashboard.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Panel4.Controls.Add(Me.jabatan)
        Me.Panel4.Controls.Add(Me.namaAnggota)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 32)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(189, 161)
        Me.Panel4.TabIndex = 1
        '
        'jabatan
        '
        Me.jabatan.AutoSize = True
        Me.jabatan.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.jabatan.ForeColor = System.Drawing.Color.White
        Me.jabatan.Location = New System.Drawing.Point(60, 105)
        Me.jabatan.Name = "jabatan"
        Me.jabatan.Size = New System.Drawing.Size(52, 18)
        Me.jabatan.TabIndex = 1
        Me.jabatan.Text = "Label2"
        Me.jabatan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'namaAnggota
        '
        Me.namaAnggota.AutoSize = True
        Me.namaAnggota.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namaAnggota.ForeColor = System.Drawing.Color.White
        Me.namaAnggota.Location = New System.Drawing.Point(60, 88)
        Me.namaAnggota.Name = "namaAnggota"
        Me.namaAnggota.Size = New System.Drawing.Size(52, 18)
        Me.namaAnggota.TabIndex = 0
        Me.namaAnggota.Text = "Label1"
        Me.namaAnggota.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(189, 32)
        Me.Panel2.TabIndex = 0
        '
        'PanelUtama
        '
        Me.PanelUtama.BackColor = System.Drawing.Color.White
        Me.PanelUtama.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelUtama.Location = New System.Drawing.Point(189, 32)
        Me.PanelUtama.Name = "PanelUtama"
        Me.PanelUtama.Size = New System.Drawing.Size(571, 504)
        Me.PanelUtama.TabIndex = 4
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Panel6)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(189, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(571, 32)
        Me.Panel3.TabIndex = 3
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.btnclose)
        Me.Panel6.Controls.Add(Me.btnmax)
        Me.Panel6.Controls.Add(Me.btnminimize)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel6.Location = New System.Drawing.Point(464, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(107, 32)
        Me.Panel6.TabIndex = 1
        '
        'btnclose
        '
        Me.btnclose.FlatAppearance.BorderSize = 0
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Image = Global.FlatDesignCarWash.My.Resources.Resources.close
        Me.btnclose.Location = New System.Drawing.Point(77, 6)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(21, 22)
        Me.btnclose.TabIndex = 4
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'btnmax
        '
        Me.btnmax.FlatAppearance.BorderSize = 0
        Me.btnmax.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmax.Image = Global.FlatDesignCarWash.My.Resources.Resources.maximize
        Me.btnmax.Location = New System.Drawing.Point(43, 6)
        Me.btnmax.Name = "btnmax"
        Me.btnmax.Size = New System.Drawing.Size(21, 22)
        Me.btnmax.TabIndex = 3
        Me.btnmax.UseVisualStyleBackColor = True
        '
        'btnminimize
        '
        Me.btnminimize.FlatAppearance.BorderSize = 0
        Me.btnminimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnminimize.Image = Global.FlatDesignCarWash.My.Resources.Resources.minimize
        Me.btnminimize.Location = New System.Drawing.Point(12, 6)
        Me.btnminimize.Name = "btnminimize"
        Me.btnminimize.Size = New System.Drawing.Size(21, 22)
        Me.btnminimize.TabIndex = 2
        Me.btnminimize.UseVisualStyleBackColor = True
        '
        'Utama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(760, 536)
        Me.Controls.Add(Me.PanelUtama)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Name = "Utama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnlogout As Button
    Friend WithEvents btnpengaturan As Button
    Friend WithEvents btnlaporan As Button
    Friend WithEvents btnproduk As Button
    Friend WithEvents btndashboard As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PanelUtama As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents btnclose As Button
    Friend WithEvents btnmax As Button
    Friend WithEvents btnminimize As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents jabatan As Label
    Friend WithEvents namaAnggota As Label
End Class
