﻿Imports System.Data.Odbc


Public Class LoginPage

    Sub bersih()
        txtpassword.Text = ""
        txtuser.Text = ""
        txtuser.Focus()
    End Sub

    Private Sub LoginPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Close()
    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Try
            If txtuser.Text = "" Or txtpassword.Text = "" Then
                MsgBox("Data Tidak Boleh Kosong !!")
            Else
                Call konek()
                cmd = New OdbcCommand("select * from karyawan where namaKaryawan= '" & txtuser.Text & "' and passwd ='" & txtpassword.Text & "'", conn)
                dr = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    Call bersih()
                    Me.Visible = True
                    Utama.btnlogout.Enabled = True
                    Utama.Show()
                    Utama.jabatan.Text = dr.Item("level")
                    If Utama.jabatan.Text = "admin" Then
                        Utama.namaAnggota.Text = dr.Item("namaKaryawan")
                        Utama.btnproduk.Enabled = True
                        Utama.btnlaporan.Enabled = True
                    ElseIf Utama.jabatan.Text = "karyawan" Then
                        Utama.namaAnggota.Text = dr.Item("namaKaryawan")
                    Else
                        MsgBox("User ID/Password Salah!", MsgBoxStyle.Critical, "Informasi")
                        Call bersih()
                    End If
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub
End Class