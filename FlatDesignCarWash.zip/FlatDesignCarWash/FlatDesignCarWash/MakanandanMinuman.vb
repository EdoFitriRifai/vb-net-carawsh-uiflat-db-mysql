﻿Public Class MakanandanMinuman
    Dim subtotal As Double

    Sub bersihpilih()
        txtnama.Text = ""
        txtharga.Text = ""
        cmbjumlah.Text = ""
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        txtnama.Text = "Nasi Goreng"
        txtharga.Text = "10000"
        cmbjumlah.Focus()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        txtnama.Text = "Mie Goreng"
        txtharga.Text = "10000"
        cmbjumlah.Focus()
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        txtnama.Text = "Es Teh Manis"
        txtharga.Text = "5000"
        cmbjumlah.Focus()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        txtnama.Text = "Kopi"
        txtharga.Text = "5000"
        cmbjumlah.Focus()
    End Sub

    Private Sub btnenter_Click(sender As Object, e As EventArgs) Handles btnenter.Click
        subtotal = 0

        Produk.lbljmlh.Text = Val(txtharga.Text) * Val(cmbjumlah.Text)
        subtotal = Produk.lbljmlh.Text
        Dim item As New ListViewItem(txtnama.Text)
        item.SubItems.Add(cmbjumlah.Text)
        item.SubItems.Add("")
        item.SubItems.Add("")
        item.SubItems.Add("")
        item.SubItems.Add(subtotal)
        Produk.ListView1.Items.Add(item)

        bersihpilih()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Produk.PanelMenupilihan.Controls.Clear()
        PilihanMenu.TopLevel = False
        PilihanMenu.AutoSize = False
        PilihanMenu.FormBorderStyle = FormBorderStyle.None
        PilihanMenu.Dock = DockStyle.Fill
        Produk.PanelMenupilihan.Controls.Add(PilihanMenu)
        PilihanMenu.Show()
    End Sub
End Class